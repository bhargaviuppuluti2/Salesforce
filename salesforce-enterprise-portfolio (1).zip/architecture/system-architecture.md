# System Architecture

User Interface
- Lightning Web Components

Business Logic
- Apex Classes
- Apex Triggers

Data Layer
- Salesforce Objects
- SOQL Queries

Integration Layer
- REST APIs
- External Systems

Testing
- Selenium
- Playwright
- Cypress

Deployment
- GitHub
- CI/CD Pipeline