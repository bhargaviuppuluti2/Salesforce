# Salesforce Enterprise Developer Portfolio

Bhargavi Uppuluti  
Senior Salesforce Developer and QA Engineer

This repository showcases enterprise Salesforce implementations including Apex automation,
Lightning Web Components development, integrations, automated testing, and CI/CD pipelines.

## Technologies
- Salesforce Platform
- Apex
- Lightning Web Components
- REST APIs
- SOQL
- Selenium Automation
- Git & CI/CD

## Projects
- Case Management Automation
- LWC Service Dashboard
- Apex Trigger Framework
- REST API Integration
- CPQ Automation
- Data Migration Batch
- Automation Testing Framework
- CI/CD Pipeline