const {Builder, By} = require("selenium-webdriver");

async function testLogin(){

let driver = await new Builder().forBrowser("chrome").build();

await driver.get("https://login.salesforce.com");

await driver.findElement(By.id("username")).sendKeys("test");

await driver.findElement(By.id("password")).sendKeys("test");

await driver.findElement(By.id("Login")).click();

}

testLogin();