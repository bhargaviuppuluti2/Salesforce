import { LightningElement, wire } from 'lwc';
import getCases from '@salesforce/apex/CaseController.getCases';

export default class ServiceDashboard extends LightningElement {

cases;

@wire(getCases)
wiredCases({error,data}){

if(data){
this.cases = data;
}

if(error){
console.error(error);
}

}

}